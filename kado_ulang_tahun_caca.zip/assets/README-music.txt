MUSIK
Untuk menggunakan "Shape of My Heart", masukkan file audio yang kamu punya secara legal/berlisensi ke folder ini dengan nama:
shape-of-my-heart.mp3

Website sengaja tidak menyertakan lagu berhak cipta tersebut.
Browser juga biasanya memblokir autoplay, jadi musik mulai setelah tombol Play ditekan.

CARA ONLINE + QR
1. Upload seluruh folder ini ke hosting statis seperti GitHub Pages, Netlify, atau Vercel.
2. Setelah mendapat URL website, buat QR dari URL tersebut.
3. File qr-placeholder.png di paket ini hanya QR contoh yang mengarah ke URL placeholder.
